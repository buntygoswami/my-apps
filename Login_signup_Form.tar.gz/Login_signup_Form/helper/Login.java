package org.IMS.mangment.Users.helper;

import java.io.IOException;
import java.util.ArrayList;

import org.IMS.mangment.Users.Dao.Database;
import org.IMS.mangment.Users.dto.Dto;

public class Login {

	public Boolean CheckLogin(Dto dto) throws ClassNotFoundException, IOException
	{
		Database database=new Database();
		ArrayList<Dto> dto2=database.Read();
		System.out.println("Login user name : "+dto.getUsername());
		System.out.println("Login password  : "+dto.getPassword());
		
		if(dto2!=null)
		{
			
			
			for(Dto dto3:dto2)
			{						

				System.out.println("Database user name : "+dto3.getUsername());
				System.out.println("Database password  : "+dto3.getPassword());
				
				if((dto3.getUsername().equals(dto.getUsername()) && (dto3.getPassword().equals(dto.getPassword()))))
				{
				
					return true;
				}
			}
			
		}
		
		
	return false;
	
	}
	
}
