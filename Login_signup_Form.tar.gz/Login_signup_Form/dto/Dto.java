package org.IMS.mangment.Users.dto;

import java.io.Serializable;

public class Dto  implements Serializable
{
	private String Username;
	private String Password;
	private String contactnumber;
	private String txtCountryName;
	private String day;
	private String month;
	private String year;
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getTxtCountryName() {
		return txtCountryName;
	}
	public void setTxtCountryName(String txtCountryName) {
		this.txtCountryName = txtCountryName;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
		
}
