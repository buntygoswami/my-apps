package org.IMS.mangment.Users.View;

public  class Test_View {

	public static void main(String[] args)
	{
			Signup signup=new Signup();
			signup.setVisible(true);
			
	}

}
