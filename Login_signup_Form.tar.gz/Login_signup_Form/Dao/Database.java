package org.IMS.mangment.Users.Dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import org.IMS.mangment.Users.View.Signup;
import org.IMS.mangment.Users.dto.Dto;

public class Database
{
	public ArrayList<Dto> Read() throws IOException, ClassNotFoundException
	{
		File path= new File("/home/pro/Desktop/User_database.dat");
		ArrayList<Dto> read=new ArrayList<Dto>();
		if(path.exists())
		{			
			FileInputStream fileinputStream=new FileInputStream(path.toString());
			ObjectInputStream objectinputStream=new ObjectInputStream(fileinputStream);						
			System.out.println("reading database");	
			read=(ArrayList<Dto>)objectinputStream.readObject();	
			fileinputStream.close();
			objectinputStream.close();				
			return read;		
		}
		
		System.out.println("old database size "+read.size());
		return read;
	}	
	public boolean Createing_database(Dto dto) throws ClassNotFoundException, IOException
	{
			
		try
		{
			ArrayList<Dto> old_record=Read();				
			old_record.add(dto);
		
				File path= new File("/home/pro/Desktop/User_database.dat");		
				FileOutputStream fileOutputStream=new FileOutputStream(path.toString());			
				ObjectOutputStream objectOutputStream=new ObjectOutputStream(fileOutputStream);		
				objectOutputStream.writeObject(old_record);			

				fileOutputStream.close();
				objectOutputStream.close();
				return true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return false;
		}
	}
	public boolean Create(Signup signup)
		{
								       
			try
				{
					Dto dto=new Dto();				
					dto.setPassword(signup.getPassword().getText());		
					dto.setUsername(signup.getFirst_name().getText());
					dto.setContactnumber(signup.getTxtContactNumber().getText());
					dto.setMonth(signup.getMonth().toString());
					dto.setMonth(signup.getDay().toString());
					dto.setMonth(signup.getYear().toString());		

					if(Createing_database(dto))  //function calling
					{
					return true;
					}				
				
				}
				catch (Exception e)
				{					
					return false;
				}		
			return false;
		}
		
}
